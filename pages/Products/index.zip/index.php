<a href="db.php">Link to DB.PHP file</a>

