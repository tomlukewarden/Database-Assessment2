<?php
$host = "espresso-express.cruet0gdarxg.us-east-1.rds.amazonaws.com";
$username = "callum";
$password = "express123";
$database = "espresso-express";

try {
    $mysql = new PDO("mysql:host=".$host.";dbname=".$database, $username, $password);
    // Set the PDO error mode to exception
    $mysql->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "DB linked Successfully! <br>";
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>
